This is the URL for the JSON file you need to fetch data from: https://learnwebcode.github.io/pet-adoption-data/pets.json
